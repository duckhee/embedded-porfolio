#ifndef __I2C_DRIVER_H
#define __I2C_DRIVER_H

//#define DMA_Master_Transmit
//#define DMA_Master_Receive
//#define DMA_Slave_Transmit
//#define DMA_Slave_Receive
//#define IT_Master_Transmit
//#define IT_Master_Receive
#define IT_Slave_Receive
//#define IT_Slave_Transmit
#define Polling_Master_Transmit
//#define Polling_Master_Receive

/* Includes */
#include "stm32f10x.h"

/* Exported constants */

#define SLAVE_ADDRESS     0x72

#define  I2C_EVENT_SLAVE_BYTE_RECEIVED_NO_BUSY   ((uint32_t)0x00000040)  /* RXNE */
#define  I2C_EVENT_SLAVE_BYTE_RECEIVED_STOPF     ((uint32_t)0x00000050)  /* STOPF, RxNE */

extern __IO uint8_t Rx_Idx;
extern uint8_t Master_Buffer_Tx[];
extern uint8_t Slave_Buffer_Rx[];

/* Exported functions */

void I2C_Check_Busy_Flag(I2C_TypeDef* I2Cx);

ErrorStatus I2C_Master_BufferWrite
        (I2C_TypeDef* I2Cx, uint8_t Address,
         uint8_t* pBuffer,  uint16_t NumByteToWrite);

#endif /* __I2C_DRIVER_H */

