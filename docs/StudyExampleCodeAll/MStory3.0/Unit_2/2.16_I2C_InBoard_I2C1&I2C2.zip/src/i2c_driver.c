
/* Includes */
#include "hw_config.h"

void I2C_Check_Busy_Flag(I2C_TypeDef* I2Cx)
{
    while (I2C_GetFlagStatus(I2Cx, I2C_FLAG_BUSY));
}

/**
  * @brief  Send a buffer of bytes to the slave.
  * @param pBuffer: Buffer of bytes to be sent to the slave.
  * @param NumByteToRead: Number of bytes to be sent to the slave.
  * @retval : None.
  */
ErrorStatus I2C_Master_BufferWrite
        (I2C_TypeDef* I2Cx, uint8_t Address,
         uint8_t* pBuffer,  uint16_t NumByteToWrite)
{
    ErrorStatus i2c_tx_eve_sts = ERROR;
    volatile uint32_t i2c_tx_eve_timeout = SystemFrequency;

    /* Send START condition */
    I2C_GenerateSTART(I2Cx, ENABLE);
    /* Test on EV5 and clear it */
    while (!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_MODE_SELECT));
    /* Send slave address for write */
    I2C_Send7bitAddress(I2Cx, Address, I2C_Direction_Transmitter);
    printf("I2C_Send7bitAddress()\n");

    /* Test on EV6 and clear it */
    i2c_tx_eve_timeout = SystemFrequency >> 7;
    while(1)
    {
        i2c_tx_eve_sts
            = I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED);
        if(SUCCESS == i2c_tx_eve_sts)
        {
            break;
        }

        i2c_tx_eve_timeout --;
        if(0 == i2c_tx_eve_timeout)
        {
            return ERROR;
        }
    }

    printf("before I2C_SendData()\n");
    I2C_SendData(I2Cx, *pBuffer);
    printf("after I2C_SendData()\n");
    pBuffer++;
    NumByteToWrite--;
    /* While there is data to be written */
    while (NumByteToWrite--)
    {
        while ((I2C_GetLastEvent(I2Cx) & 0x08) != 0x08);  /* Poll on TxE */
        /* Send the current byte */
        I2C_SendData(I2Cx, *pBuffer);
        /* Point to the next byte to be written */
        pBuffer++;
    }

    printf("before I2C_EVENT_MASTER_BYTE_TRANSMITTED\n");
    /* Test on EV8_2 and clear it, BTF = TxE = 1, DR and shift registers are
     empty */
    while (!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED));
    printf("after I2C_EVENT_MASTER_BYTE_TRANSMITTED\n");
    /* Send STOP condition */
    I2C_GenerateSTOP(I2Cx, ENABLE);

    return SUCCESS;
}

