/*
 * (C) COPYRIGHT 2009 CRZ
 *
 * File Name : main.c
 * Author    : POOH
 * Version   : V1.0
 * Date      : 08/12/2009
 */

/* includes */

#include "hw_config.h"

/* global variables */

RCC_ClocksTypeDef  rcc_clocks;

bool g_TestProcessState = FALSE;

/* functions */

void System_Information()
{
    printf("SYSCLK_Frequency = %d\n",rcc_clocks.SYSCLK_Frequency );
    printf("HCLK_Frequency = %d\n",rcc_clocks.HCLK_Frequency );
    printf("PCLK1_Frequency = %d\n",rcc_clocks.PCLK1_Frequency );
    printf("PCLK2_Frequency = %d\n",rcc_clocks.PCLK2_Frequency );
    printf("ADCCLK_Frequency = %d\n",rcc_clocks.ADCCLK_Frequency );
}

void USB_Test_Start (void)
{
    USB_Interrupts_Config();
    Set_USBClock();
    USB_Init();
}

typedef enum { FAILED = 0, PASSED = !FAILED} TestStatus;

#define TxBufferSize   (countof(TxBuffer))
#define countof(a)   (sizeof(a) / sizeof(*(a)))

uint8_t TxBuffer[] = "Buffer Send from USARTy to USARTz using Flags";
uint8_t RxBuffer[TxBufferSize + 1];

/**
  * @brief  Compares two buffers.
  * @param  pBuffer1, pBuffer2: buffers to be compared.
  * @param  BufferLength: buffer's length
  * @retval PASSED: pBuffer1 identical to pBuffer2
  *   FAILED: pBuffer1 differs from pBuffer2
  */
TestStatus Buffercmp(uint8_t* pBuffer1, uint8_t* pBuffer2, uint16_t BufferLength)
{
    while(BufferLength--)
    {
        if(*pBuffer1 != *pBuffer2)
        {
            return FAILED;
        }

        pBuffer1++;
        pBuffer2++;
    }

    return PASSED;
}

void USART_Polling_UART2_3_Test(void)
{
    USART_InitTypeDef USART_InitStructure;
    uint8_t counter = 0;
    TestStatus TransferStatus = FAILED;  

    printf("USART_Polling_UART2_3_Test()\n");

    /* USARTy and USARTz configured as follow:
    - BaudRate = 230400 baud  
    - Word Length = 8 Bits
    - One Stop Bit
    - Even parity
    - Hardware flow control disabled (RTS and CTS signals)
    - Receive and transmit enabled
    */
    USART_InitStructure.USART_BaudRate = 230400;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_Even;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

    /* Configure USART_tx */
    USART_Init(USART_tx, &USART_InitStructure);

    /* Enable the USART_tx */
    USART_Cmd(USART_tx, ENABLE);

    /* Configure USART_rx */
    USART_Init(USART_rx, &USART_InitStructure);

    /* Enable the USART_rx */
    USART_Cmd(USART_rx, ENABLE);

    while(counter < TxBufferSize)
    {   
        /* Send one byte from USARTy to USARTz */
        USART_SendData(USART_tx, TxBuffer[counter]);
        printf("[%d] USART2 Send: 0x%0X\n", counter, TxBuffer[counter]);

        /* Loop until USARTy DR register is empty */ 
        while(USART_GetFlagStatus(USART_tx, USART_FLAG_TXE) == RESET);
        printf("[%d] USART2 Send Complete\n", counter);

        /* Loop until the USARTz Receive Data Register is not empty */
        while(USART_GetFlagStatus(USART_rx, USART_FLAG_RXNE) == RESET);
        printf("[%d] USART3 Receive Complete\n", counter);

        /* Store the received byte in RxBuffer */
        RxBuffer[counter] = (USART_ReceiveData(USART_rx) & 0x7F);  
        printf("[%d] USART3 Receive: 0x%0X\n", counter, RxBuffer[counter]);

        counter++;
    }

    /* Check the received data with the send ones */
    TransferStatus = Buffercmp(TxBuffer, RxBuffer, TxBufferSize);

    if(PASSED == TransferStatus)
    {
        printf("Transfer Status PASSED\n");
    }
    else
    {
        printf("Transfer Status FAILED\n");
    }

    printf("TxBuffer: %s\n", TxBuffer);
    printf("RxBuffer: %s\n", RxBuffer);

    while (1)
    {
    }
}

/*
 * Name   : main
 * Input  : None
 * Output : None
 * Return : None
 */
int main(void)
{
    /* System Clocks Configuration */
    RCC_Configuration();

    RCC_GetClocksFreq(&rcc_clocks);

    /* NVIC configuration */
    NVIC_Configuration();

    /* Configure the GPIO ports */
    GPIO_Configuration();

    /* EXTI configuration */
    EXTI_Configuration();

    /* UART initialization */
    USART1_Init();

    /* Setup SysTick Timer for 1 msec interrupts  */
    if (SysTick_Config(rcc_clocks.SYSCLK_Frequency / 1000))
    { 
        /* Capture error */ 
        while (1);
    }

    USB_Cable_Config(DISABLE);

    Delay(500);

    USART_GetCharacter(USART1);
    USART_Polling_UART2_3_Test();

#if 0
    while(1)
    {
        printf("\n---------------------\n");
#ifdef BOARD_DEF_MANGO_M32
        printf("Mango M32 test start...\n");
#elif  BOARD_DEF_MANGO_Z1
        printf("Mango Z1 test start...\n");
#endif
        printf("Press menu key\n");
        printf("---------------------\n");
        printf("0> System Information\n");
        printf("---------------------\n");
        printf("1> LED Test\n");
        printf("2> KEY Test\n");
#ifdef BOARD_DEF_MANGO_M32
        printf("3> 7-Segment Test\n");
#elif  BOARD_DEF_MANGO_Z1
        printf("3> ZigBee Test\n");
#endif
        printf("4> USB HID Test\n");
        printf("5> \n");
        printf("---------------------\n");
        printf("x> quit\n\n");

        ch = USART_GetCharacter(USART1);
        printf(" is selected\n\n");

        switch((char)ch)
        {
        case '0':
            System_Information();
            break;

        case '1':
            LED_Test();
            break;

        case '2':
            KEY_Test();
            break;

        case '3':
#ifdef BOARD_DEF_MANGO_M32
            Seven_Segment_Test();
#elif  BOARD_DEF_MANGO_Z1
            ZigBee_Test();
#endif
            break;

        case '4':
            g_TestProcessState = TRUE;

            /* USB initialization */
            USB_Test_Start();
            Delay(500);
            USB_Cable_Config(ENABLE);
            break;

        case '5':
            break;
        }

        if('x' == (char)ch)
        {
            break;
        }
    }
#endif

    return 0;
}
