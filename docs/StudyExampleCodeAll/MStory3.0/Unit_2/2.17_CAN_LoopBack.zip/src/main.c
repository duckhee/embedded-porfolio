/*
 * (C) COPYRIGHT 2009 CRZ
 *
 * File Name : main.c
 * Author    : POOH
 * Version   : V1.0
 * Date      : 08/12/2009
 */

/* includes */

#include "hw_config.h"

/* global variables */

RCC_ClocksTypeDef  rcc_clocks;

bool g_TestProcessState = FALSE;

/* functions */

void System_Information()
{
    printf("SYSCLK_Frequency = %d\n",rcc_clocks.SYSCLK_Frequency );
    printf("HCLK_Frequency = %d\n",rcc_clocks.HCLK_Frequency );
    printf("PCLK1_Frequency = %d\n",rcc_clocks.PCLK1_Frequency );
    printf("PCLK2_Frequency = %d\n",rcc_clocks.PCLK2_Frequency );
    printf("ADCCLK_Frequency = %d\n",rcc_clocks.ADCCLK_Frequency );
}

void USB_Test_Start (void)
{
    USB_Interrupts_Config();
    Set_USBClock();
    USB_Init();
}

void CAN_Configuration(void)
{
    CAN_InitTypeDef        CAN_InitStructure;

    /* CAN register init */
    CAN_DeInit(CAN1);
    CAN_StructInit(&CAN_InitStructure);

    /* CAN cell init */
    CAN_InitStructure.CAN_TTCM=DISABLE;
    CAN_InitStructure.CAN_ABOM=DISABLE;
    CAN_InitStructure.CAN_AWUM=DISABLE;
    CAN_InitStructure.CAN_NART=DISABLE;
    CAN_InitStructure.CAN_RFLM=DISABLE;
    CAN_InitStructure.CAN_TXFP=DISABLE;
    CAN_InitStructure.CAN_Mode=CAN_Mode_LoopBack;
    CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;
    CAN_InitStructure.CAN_BS1=CAN_BS1_8tq;
    CAN_InitStructure.CAN_BS2=CAN_BS2_7tq;
    CAN_InitStructure.CAN_Prescaler=10;
    CAN_Init(CAN1, &CAN_InitStructure);
}

typedef enum {FAILED = 0, PASSED = !FAILED} TestStatus;
volatile TestStatus TestRx;

TestStatus CAN_Polling(void)
{
    CanTxMsg TxMessage;
    CanRxMsg RxMessage;
    uint32_t i = 0;
    uint8_t TransmitMailbox = 0;

    /* transmit */
    TxMessage.StdId=0x11;
    TxMessage.RTR=CAN_RTR_DATA;
    TxMessage.IDE=CAN_ID_STD;
    TxMessage.DLC=2;
    TxMessage.Data[0]=0xCA;
    TxMessage.Data[1]=0xFE;

    TransmitMailbox=CAN_Transmit(CAN1, &TxMessage);
    i = 0;
    while((CAN_TransmitStatus(CAN1, TransmitMailbox) != CANTXOK) && (i != 0xFF))
    {
        i++;
    }

    i = 0;
    while((CAN_MessagePending(CAN1, CAN_FIFO0) < 1) && (i != 0xFF))
    {
        i++;
    }

    /* receive */
    RxMessage.StdId=0x00;
    RxMessage.IDE=CAN_ID_STD;
    RxMessage.DLC=0;
    RxMessage.Data[0]=0x00;
    RxMessage.Data[1]=0x00;
    CAN_Receive(CAN1, CAN_FIFO0, &RxMessage);

    if (RxMessage.StdId != 0x11)
    {
        printf("[ERROR] StdId != 0x11\n");
        return FAILED;  
    }
    printf("StdId == 0x11\n");

    if (RxMessage.IDE != CAN_ID_STD)
    {
        printf("[ERROR] IDE != CAN_ID_STD\n");
        return FAILED;
    }
    printf("IDE == CAN_ID_STD\n");

    if (RxMessage.DLC != 2)
    {
        printf("[ERROR] DLC != 2\n");
        return FAILED;  
    }
    printf("DLC == 2\n");

    if ((RxMessage.Data[0]<<8|RxMessage.Data[1])!=0xCAFE)
    {
        printf("[ERROR] Data != 0xCAFE\n");
        return FAILED;
    }
    printf("Data == 0xCAFE\n");

    return PASSED; /* Test Passed */
}

void CAN_LoopBack_Test(void)
{
    LED_Off_All();

    /* CAN transmit at 100Kb/s and receive by polling in loopback mode */
    TestRx = CAN_Polling();

    if (TestRx == FAILED)
    {
        printf("[ERROR] CAN_Polling() FAILED\n");
    }
    else
    {
        printf("CAN_Polling() PASSED\n");
    }
}

/*
 * Name   : main
 * Input  : None
 * Output : None
 * Return : None
 */
int main(void)
{
    uint8_t ch;

    /* System Clocks Configuration */
    RCC_Configuration();

    RCC_GetClocksFreq(&rcc_clocks);

    /* NVIC configuration */
    NVIC_Configuration();

    /* Configure the GPIO ports */
    GPIO_Configuration();

    /* EXTI configuration */
    EXTI_Configuration();

    /* UART initialization */
    USART1_Init();

    /* Setup SysTick Timer for 1 msec interrupts  */
    if (SysTick_Config(rcc_clocks.SYSCLK_Frequency / 1000))
    { 
        /* Capture error */ 
        while (1);
    }

    USB_Cable_Config(DISABLE);

    CAN_Configuration();

    Delay(500);

    while(1)
    {
        printf("\n---------------------\n");
#ifdef BOARD_DEF_MANGO_M32
        printf("Mango M32 test start...\n");
#elif  BOARD_DEF_MANGO_Z1
        printf("Mango Z1 test start...\n");
#endif
        printf("Press menu key\n");
        printf("---------------------\n");
        printf("0> System Information\n");
        printf("---------------------\n");
        printf("1> LED Test\n");
        printf("2> KEY Test\n");
#ifdef BOARD_DEF_MANGO_M32
        printf("3> 7-Segment Test\n");
#elif  BOARD_DEF_MANGO_Z1
        printf("3> ZigBee Test\n");
#endif
        printf("4> USB HID Test\n");
        printf("5> CAN Loop Back Test\n");
        printf("---------------------\n");
        printf("x> quit\n\n");

        ch = USART_GetCharacter(USART1);
        printf(" is selected\n\n");

        switch((char)ch)
        {
        case '0':
            System_Information();
            break;

        case '1':
            LED_Test();
            break;

        case '2':
            KEY_Test();
            break;

        case '3':
#ifdef BOARD_DEF_MANGO_M32
            Seven_Segment_Test();
#elif  BOARD_DEF_MANGO_Z1
            ZigBee_Test();
#endif
            break;

        case '4':
            g_TestProcessState = TRUE;

            /* USB initialization */
            USB_Test_Start();
            Delay(500);
            USB_Cable_Config(ENABLE);
            break;

        case '5':
            CAN_LoopBack_Test();
            break;
        }

        if('x' == (char)ch)
        {
            break;
        }
    }

    return 0;
}
