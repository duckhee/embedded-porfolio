/*
 * (C) COPYRIGHT 2009 CRZ
 *
 * File Name : main.c
 * Author    : POOH
 * Version   : V1.0
 * Date      : 08/12/2009
 */

/* includes */

#include "hw_config.h"

/* global variables */

RCC_ClocksTypeDef  rcc_clocks;

bool g_TestProcessState = FALSE;

/* functions */

void System_Information()
{
    printf("SYSCLK_Frequency = %d\n",rcc_clocks.SYSCLK_Frequency );
    printf("HCLK_Frequency = %d\n",rcc_clocks.HCLK_Frequency );
    printf("PCLK1_Frequency = %d\n",rcc_clocks.PCLK1_Frequency );
    printf("PCLK2_Frequency = %d\n",rcc_clocks.PCLK2_Frequency );
    printf("ADCCLK_Frequency = %d\n",rcc_clocks.ADCCLK_Frequency );
}

void USB_Test_Start (void)
{
    USB_Interrupts_Config();
    Set_USBClock();
    USB_Init();
}

#define  U3_BUFFER_SIZE  100

uint16_t  u3_rx_buffer[U3_BUFFER_SIZE];

uint32_t  u3_rx_point_head = 0;
uint32_t  u3_rx_point_tail = 0;

void u3_increase_point_value(uint32_t * data_p)
{
    (* data_p) ++;
    if(U3_BUFFER_SIZE == (* data_p))
    {
        (* data_p) = 0;
    }
}

bool Uart3_Is_Empty(void)
{
    if(u3_rx_point_head == u3_rx_point_tail)
    {
        return TRUE;
    }
    return FALSE;
}

void Uart3_EnQueue(uint16_t data)
{
    u3_rx_buffer[u3_rx_point_head] = data;
    u3_increase_point_value(&u3_rx_point_head);
}

uint16_t Uart3_DeQueue(void)
{
    uint16_t retVal = u3_rx_buffer[u3_rx_point_tail];
    u3_increase_point_value(&u3_rx_point_tail);
    return retVal;
}

void USART_Interrupt_Test(void)
{
    USART_InitTypeDef USART_InitStructure;
    uint16_t data = 0;

    printf("USART_Interrupt_Test()\n");

    /* USARTy and USARTz configured as follow:
    - BaudRate = 230400 baud  
    - Word Length = 8 Bits
    - One Stop Bit
    - Even parity
    - Hardware flow control disabled (RTS and CTS signals)
    - Receive and transmit enabled
    */
    USART_InitStructure.USART_BaudRate = 230400;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
//    USART_InitStructure.USART_Parity = USART_Parity_Even;
    USART_InitStructure.USART_Parity = USART_Parity_Odd;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

#ifdef BOARD_DEF_MANGO_Z1
    /* Configure USART_tx */
    USART_Init(USART_tx, &USART_InitStructure);

    /* Enable the USART_tx */
    USART_Cmd(USART_tx, ENABLE);
#elif  BOARD_DEF_MANGO_M32
    /* Configure USART_rx */
    USART_Init(USART_rx, &USART_InitStructure);

    /* Enable Receive interrupts */
    USART_ITConfig(USART_rx, USART_IT_RXNE, ENABLE);

    /* Enable the USART_rx */
    USART_Cmd(USART_rx, ENABLE);
#endif

    while(1)
    {   
#ifdef BOARD_DEF_MANGO_Z1
        /* Send one byte from USARTy to USARTz */
        USART_SendData(USART_tx, data);
        printf("USART2 Send: 0x%0X\n", data);

        /* Loop until USARTy DR register is empty */ 
        while(USART_GetFlagStatus(USART_tx, USART_FLAG_TXE) == RESET);

        Delay(200);
        data++;
        if(0x80 == data) data = 0;

#elif  BOARD_DEF_MANGO_M32
        if(FALSE == Uart3_Is_Empty())
        {
            data = Uart3_DeQueue();
            printf("USART3 Rx org: 0x%0X, real data: 0x%0X\n", data, data & 0x7F);
        }
#endif
    }
}

/*
 * Name   : main
 * Input  : None
 * Output : None
 * Return : None
 */
int main(void)
{
    /* System Clocks Configuration */
    RCC_Configuration();

    RCC_GetClocksFreq(&rcc_clocks);

    /* NVIC configuration */
    NVIC_Configuration();

    /* Configure the GPIO ports */
    GPIO_Configuration();

    /* EXTI configuration */
    EXTI_Configuration();

    /* UART initialization */
    USART1_Init();

    /* Setup SysTick Timer for 1 msec interrupts  */
    if (SysTick_Config(rcc_clocks.SYSCLK_Frequency / 1000))
    { 
        /* Capture error */ 
        while (1);
    }

    USB_Cable_Config(DISABLE);

    Delay(500);

    USART_GetCharacter(USART1);
    USART_Interrupt_Test();

#if 0
    while(1)
    {
        printf("\n---------------------\n");
#ifdef BOARD_DEF_MANGO_M32
        printf("Mango M32 test start...\n");
#elif  BOARD_DEF_MANGO_Z1
        printf("Mango Z1 test start...\n");
#endif
        printf("Press menu key\n");
        printf("---------------------\n");
        printf("0> System Information\n");
        printf("---------------------\n");
        printf("1> LED Test\n");
        printf("2> KEY Test\n");
#ifdef BOARD_DEF_MANGO_M32
        printf("3> 7-Segment Test\n");
#elif  BOARD_DEF_MANGO_Z1
        printf("3> ZigBee Test\n");
#endif
        printf("4> USB HID Test\n");
        printf("5> \n");
        printf("---------------------\n");
        printf("x> quit\n\n");

        ch = USART_GetCharacter(USART1);
        printf(" is selected\n\n");

        switch((char)ch)
        {
        case '0':
            System_Information();
            break;

        case '1':
            LED_Test();
            break;

        case '2':
            KEY_Test();
            break;

        case '3':
#ifdef BOARD_DEF_MANGO_M32
            Seven_Segment_Test();
#elif  BOARD_DEF_MANGO_Z1
            ZigBee_Test();
#endif
            break;

        case '4':
            g_TestProcessState = TRUE;

            /* USB initialization */
            USB_Test_Start();
            Delay(500);
            USB_Cable_Config(ENABLE);
            break;

        case '5':
            break;
        }

        if('x' == (char)ch)
        {
            break;
        }
    }
#endif

    return 0;
}
