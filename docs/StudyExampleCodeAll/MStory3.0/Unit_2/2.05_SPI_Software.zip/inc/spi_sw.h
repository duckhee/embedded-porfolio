/*
 * (C) COPYRIGHT 2009 CRZ
 *
 * File Name : spi_sw.h
 * Author    : POOH
 * Version   : V1.0
 * Date      : 09/23/2009
 */

#ifndef __SPI_SW_H
#define __SPI_SW_H

/* includes */

#include "hw_config.h"

/* defines */

/* functions */

void SW_SPI_CLK_Init(void);
uint8 SW_SPI_TXRX(uint8 tx_data);

#endif  /* __SPI_SW_H */
