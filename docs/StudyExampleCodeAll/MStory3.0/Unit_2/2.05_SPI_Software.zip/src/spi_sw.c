/*
 * (C) COPYRIGHT 2009 CRZ
 *
 * File Name : spi_sw.c
 * Author    : POOH
 * Version   : V1.0
 * Date      : 09/23/2009
 */

#include "hw_config.h"
#include "debug.h"
#include "spi_sw.h"

#define SW_SPI_WAIT_TIME  100

uint32 SW_SPI_CPHA_val = 0;
uint32 SW_SPI_CPOL_val = 0;

void TIMER_Wait_us(__IO uint32_t nCount)
{
    for (; nCount != 0;nCount--);
}

uint8_t SW_SPI_ReadVal_MISO(void)
{
    return GPIO_ReadInputDataBit(GPIO_RF_SPI, GPIO_RF_SPI_MISO_PIN);
}

// SPI MOSI High
void SW_SPI_MOSI_H(void)
{
    GPIO_SetBits(GPIO_RF_SPI, GPIO_RF_SPI_MOSI_PIN);
}

// SPI MOSI low
void SW_SPI_MOSI_L(void)
{
    GPIO_ResetBits(GPIO_RF_SPI, GPIO_RF_SPI_MOSI_PIN);
}

// SPI CLK High
void SW_SPI_CLK_H(void)
{
    GPIO_SetBits(GPIO_RF_SPI, GPIO_RF_SPI_CLK_PIN);
}

// SPI CLK low
void SW_SPI_CLK_L(void)
{
    GPIO_ResetBits(GPIO_RF_SPI, GPIO_RF_SPI_CLK_PIN);
}

void SW_SPI_MOSI_OUT(uint8_t out)
{
    if (out)
    {
        SW_SPI_MOSI_H();
    }
    else
    {
        SW_SPI_MOSI_L();
    }
    TIMER_Wait_us(SW_SPI_WAIT_TIME);
}

void SW_SPI_CLK_Init(void)
{
    if(0 == SW_SPI_CPOL_val)
    {
        SW_SPI_CLK_L();
    }
    else
    {
        SW_SPI_CLK_H();
    }
    TIMER_Wait_us(SW_SPI_WAIT_TIME);
}

void SW_SPI_CLK_Toggle(void)
{
    GPIO_WriteBit(GPIO_RF_SPI, GPIO_RF_SPI_CLK_PIN,
        (BitAction)(1-GPIO_ReadOutputDataBit(GPIO_RF_SPI, GPIO_RF_SPI_CLK_PIN)));
    TIMER_Wait_us(SW_SPI_WAIT_TIME);
}

uint8 SW_SPI_TXRX(uint8 tx_data)
{
    uint8  rx_data = 0;

    uint32 i;
    uint8 bitCheckVal = 0x80;

    if(1 == SW_SPI_CPHA_val)
    {
        SW_SPI_CLK_Toggle();    
    }

	for (i=0; i<8; i++) 
	{
		SW_SPI_MOSI_OUT(tx_data & bitCheckVal);
		bitCheckVal >>= 1;

        SW_SPI_CLK_Toggle();    

        rx_data <<= 1;
        if(SW_SPI_ReadVal_MISO() == Bit_SET)
        {
            rx_data |= 0x1;
        }

        if((7 == i) && (1 == SW_SPI_CPHA_val))
        {    // In last loop, if CPHA is 1, should skip CLK Toggle ...
            break;
        }
        SW_SPI_CLK_Toggle();    
	}

    TIMER_Wait_us(SW_SPI_WAIT_TIME);
    return rx_data;
}

