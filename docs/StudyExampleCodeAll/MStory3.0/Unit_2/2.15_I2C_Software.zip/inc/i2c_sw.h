/*
 * (C) COPYRIGHT 2009 CRZ
 *
 * File Name : i2c_sw.h
 * Author    : POOH
 * Version   : V1.0
 * Date      : 09/28/2009
 */

#ifndef __I2C_SW_H
#define __I2C_SW_H

/* includes */

#include "stm32f10x.h"
#include "stdio.h"

/* defines */

/* functions */

uint8_t SW_I2C_ReadVal_SDA(void);

void SW_I2C_Write_Data(uint8_t data);
uint8_t SW_I2C_Read_Data(void);

uint8_t SW_I2C_WriteControl_8Bit
                (uint8_t IICID, uint8_t regaddr, uint8_t data);
uint8_t SW_I2C_WriteControl_16Bit
                (uint8_t IICID, uint8_t regaddr, uint16_t data);

uint8_t SW_I2C_ReadControl_8Bit(uint8_t IICID, uint8_t regaddr);
uint16_t SW_I2C_ReadControl_16Bit(uint8_t IICID, uint8_t regaddr);

#endif  /* __I2C_SW_H */
