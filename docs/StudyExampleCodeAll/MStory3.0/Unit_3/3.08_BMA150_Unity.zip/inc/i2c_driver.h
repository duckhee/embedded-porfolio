#ifndef __I2C_DRIVER_H
#define __I2C_DRIVER_H

#define Polling_Master_Transmit

/* Includes */
#include "stm32f10x.h"

/* Exported constants */

#define SLAVE_ADDRESS     0x70
#define I2C1_DR_Address    0x40005410
#define I2C2_DR_Address    0x40005810

#define  I2C_EVENT_MASTER_BYTE_RECEIVED_NO_BUSY  ((uint32_t)0x00000040)  /* RxNE */
#define  I2C_EVENT_SLAVE_BYTE_RECEIVED_NO_BUSY   ((uint32_t)0x00000040)  /* RXNE */
#define  I2C_EVENT_SLAVE_BYTE_RECEIVED_STOPF     ((uint32_t)0x00000050)  /* STOPF, RxNE */
#define  I2C_EVENT_SLAVE_BYTE_TRANSMITTING       ((uint32_t)0x00060080)  /* TRA, BUSY, TXE */
#define  I2C_EVENT_MASTER_BYTE_RECEIVED_BTF      ((uint32_t)0x00030044)  /* BUSY, MSL, RXNE, BTF */

/* Exported functions */

void I2C_Check_Busy_Flag(I2C_TypeDef* I2Cx);

void I2C_Master_BufferRead(I2C_TypeDef* I2Cx, uint8_t Address,
         uint8_t* pBuffer,  uint16_t NumByteToRead);
ErrorStatus I2C_Master_BufferWrite
        (I2C_TypeDef* I2Cx, uint8_t Address,
         uint8_t* pBuffer,  uint16_t NumByteToWrite);
uint8_t I2C_Master_BufferRead1Byte(I2C_TypeDef* I2Cx, uint8_t Address);
void I2C_Master_BufferRead2Byte
        (I2C_TypeDef* I2Cx, uint8_t Address, uint8_t* pBuffer);

#endif /* __I2C_DRIVER_H */

