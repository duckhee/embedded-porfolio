/*
 * (C) COPYRIGHT 2009 CRZ
 *
 * File Name : bma150.c
 * Author    : POOH
 * Version   : V1.0
 * Date      : 12/30/2009
 */

/* includes */

#include "hw_config.h"

/* defines */

#define BufferSize 2

#define CHIP_ID_REG			0x00
#define VERSION_REG			0x01
#define X_AXIS_LSB_REG		0x02
#define X_AXIS_MSB_REG		0x03
#define Y_AXIS_LSB_REG		0x04
#define Y_AXIS_MSB_REG		0x05
#define Z_AXIS_LSB_REG		0x06
#define Z_AXIS_MSB_REG		0x07
#define TEMP_RD_REG			0x08
#define SMB380_STATUS_REG	0x09
#define SMB380_CTRL_REG		0x0a
#define SMB380_CONF1_REG	0x0b
#define LG_THRESHOLD_REG	0x0c
#define LG_DURATION_REG		0x0d
#define HG_THRESHOLD_REG	0x0e
#define HG_DURATION_REG		0x0f
#define MOTION_THRS_REG		0x10
#define HYSTERESIS_REG		0x11
#define CUSTOMER1_REG		0x12
#define CUSTOMER2_REG		0x13
#define RANGE_BWIDTH_REG	0x14
#define SMB380_CONF2_REG	0x15

#define OFFS_GAIN_X_REG		0x16
#define OFFS_GAIN_Y_REG		0x17
#define OFFS_GAIN_Z_REG		0x18
#define OFFS_GAIN_T_REG		0x19
#define OFFSET_X_REG		0x1a
#define OFFSET_Y_REG		0x1b
#define OFFSET_Z_REG		0x1c
#define OFFSET_T_REG		0x1d

/* variables */

extern bool BMA150_COMTOOL_IS_I2C;

uint8_t Buffer_Tx[BufferSize];
uint8_t Buffer_Rx[BufferSize];

/* functions */

uint8_t Read_1_Byte(uint8_t address)
{
    if(TRUE == BMA150_COMTOOL_IS_I2C)
    {
        I2C_Check_Busy_Flag(I2C1);
        Buffer_Tx[0] = address;
        I2C_Master_BufferWrite(I2C1, SLAVE_ADDRESS, Buffer_Tx, 1);
        I2C_Master_BufferRead(I2C1, SLAVE_ADDRESS, Buffer_Rx, 1);
        return Buffer_Rx[0];
    }
    else
    {
        Buffer_Tx[0] = 0x80;
        Buffer_Tx[1] = address;

        SPI_BEGIN();

        /* Wait for SPIy Tx buffer empty */
        while (SPI_I2S_GetFlagStatus(SPI_NUM, SPI_I2S_FLAG_TXE) == RESET);
        /* Send SPIy data */
        SPI_I2S_SendData(SPI_NUM, Buffer_Tx[0]);

        /* Wait for SPIy data reception */
        while (SPI_I2S_GetFlagStatus(SPI_NUM, SPI_I2S_FLAG_RXNE) == RESET);
        /* Read SPIy received data */
        Buffer_Rx[0] = SPI_I2S_ReceiveData(SPI_NUM);

        /* Wait for SPIy Tx buffer empty */
        while (SPI_I2S_GetFlagStatus(SPI_NUM, SPI_I2S_FLAG_TXE) == RESET);
        /* Send SPIy data */
        SPI_I2S_SendData(SPI_NUM, Buffer_Tx[1]);

        /* Wait for SPIy data reception */
        while (SPI_I2S_GetFlagStatus(SPI_NUM, SPI_I2S_FLAG_RXNE) == RESET);
        /* Read SPIy received data */
        Buffer_Rx[1] = SPI_I2S_ReceiveData(SPI_NUM);

        SPI_END();

        return Buffer_Rx[1];
    }
}

uint8_t Get_ChipID(void)
{
    return Read_1_Byte(CHIP_ID_REG);
}

void BMA150_Test(void)
{
    DEBUG_MSG_FUNC_START;

    printf("Chip ID: 0x%0X\n", Get_ChipID());
}

