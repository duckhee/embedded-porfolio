
/* Includes */
#include "hw_config.h"

void I2C_Check_Busy_Flag(I2C_TypeDef* I2Cx)
{
    while (I2C_GetFlagStatus(I2Cx, I2C_FLAG_BUSY));
}

/**
  * @brief  Read a byte from the slave.
  * @param ne.
  * @retval : The read data byte.
  */
uint8_t I2C_Master_BufferRead1Byte(I2C_TypeDef* I2Cx, uint8_t Address)
{
    uint8_t Data;
    __IO uint32_t temp;
    /* Send START condition */
    I2C_GenerateSTART(I2Cx, ENABLE);
    while (!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_MODE_SELECT));
    /* Send EEPROM address for read */
    I2C_Send7bitAddress(I2Cx, Address, I2C_Direction_Receiver);
    /* Wait until ADDR is set */
    while (!I2C_GetFlagStatus(I2Cx, I2C_FLAG_ADDR));
    /* Clear ACK */
    I2C_AcknowledgeConfig(I2Cx, DISABLE);
    __disable_irq();
    /* Clear ADDR flag */
    temp = I2Cx->SR2;
    /* Program the STOP */
    I2C_GenerateSTOP(I2Cx, ENABLE);
    __enable_irq();
    while ((I2C_GetLastEvent(I2Cx) & 0x0040) != 0x000040); /* Poll on RxNE */
    /* Read the data */
    Data = I2C_ReceiveData(I2Cx);
    /* Make sure that the STOP bit is cleared by Hardware before CR1 write access */
    while ((I2Cx->CR1&0x200) == 0x200);
    /* Enable Acknowledgement to be ready for another reception */
    I2C_AcknowledgeConfig(I2Cx, ENABLE);

    return(Data);
}

/**
  * @brief  Send a buffer of bytes to the slave.
  * @param pBuffer: Buffer of bytes to be sent to the slave.
  * @param NumByteToRead: Number of bytes to be sent to the slave.
  * @retval : None.
  */
ErrorStatus I2C_Master_BufferWrite
        (I2C_TypeDef* I2Cx, uint8_t Address,
         uint8_t* pBuffer,  uint16_t NumByteToWrite)
{
    ErrorStatus i2c_tx_eve_sts = ERROR;
    volatile uint32_t i2c_tx_eve_timeout = SystemFrequency;

    /* Send START condition */
    I2C_GenerateSTART(I2Cx, ENABLE);
    /* Test on EV5 and clear it */
    while (!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_MODE_SELECT));
    /* Send slave address for write */
    I2C_Send7bitAddress(I2Cx, Address, I2C_Direction_Transmitter);

    /* Test on EV6 and clear it */
    i2c_tx_eve_timeout = SystemFrequency >> 7;
    while(1)
    {
        i2c_tx_eve_sts
            = I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED);
        if(SUCCESS == i2c_tx_eve_sts)
        {
            break;
        }

        i2c_tx_eve_timeout --;
        if(0 == i2c_tx_eve_timeout)
        {
            return ERROR;
        }
    }

    I2C_SendData(I2Cx, *pBuffer);
    pBuffer++;
    NumByteToWrite--;
    /* While there is data to be written */
    while (NumByteToWrite--)
    {
        while ((I2C_GetLastEvent(I2Cx) & 0x08) != 0x08);  /* Poll on TxE */
        /* Send the current byte */
        I2C_SendData(I2Cx, *pBuffer);
        /* Point to the next byte to be written */
        pBuffer++;
    }

    /* Test on EV8_2 and clear it, BTF = TxE = 1, DR and shift registers are
     empty */
    while (!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED));
    /* Send STOP condition */
    I2C_GenerateSTOP(I2Cx, ENABLE);

    return SUCCESS;
}
