#ifndef __I2C_DRIVER_H
#define __I2C_DRIVER_H

/* Includes */

#include "stm32f10x.h"

/* Exported constants */

#define SLAVE_ADDRESS     0x70

extern uint8_t Master_Buffer_Tx[], Master_Buffer_Rx[];

/* Exported functions */

void I2C_Check_Busy_Flag(I2C_TypeDef* I2Cx);

uint8_t I2C_Master_BufferRead1Byte(I2C_TypeDef* I2Cx, uint8_t Address);
ErrorStatus I2C_Master_BufferWrite
        (I2C_TypeDef* I2Cx, uint8_t Address,
         uint8_t* pBuffer,  uint16_t NumByteToWrite);

#endif /* __I2C_DRIVER_H */

