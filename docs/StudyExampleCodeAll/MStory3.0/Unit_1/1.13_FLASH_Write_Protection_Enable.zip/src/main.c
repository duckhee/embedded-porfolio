/*
 * (C) COPYRIGHT 2009 CRZ
 *
 * File Name : main.c
 * Author    : POOH
 * Version   : V1.0
 * Date      : 08/12/2009
 */

/* includes */

#include "hw_config.h"

/* global variables */

RCC_ClocksTypeDef  rcc_clocks;

bool g_TestProcessState = FALSE;

/* functions */

void System_Information()
{
    printf("SYSCLK_Frequency = %d\n",rcc_clocks.SYSCLK_Frequency );
    printf("HCLK_Frequency = %d\n",rcc_clocks.HCLK_Frequency );
    printf("PCLK1_Frequency = %d\n",rcc_clocks.PCLK1_Frequency );
    printf("PCLK2_Frequency = %d\n",rcc_clocks.PCLK2_Frequency );
    printf("ADCCLK_Frequency = %d\n",rcc_clocks.ADCCLK_Frequency );
}

void USB_Test_Start (void)
{
    USB_Interrupts_Config();
    Set_USBClock();
    USB_Init();
}

typedef enum {FAILED = 0, PASSED = !FAILED} TestStatus;

/* Define the STM32F10x FLASH Page Size depending on the used STM32 device */
#ifdef STM32F10X_LD
  #define FLASH_PAGE_SIZE    ((uint16_t)0x400)
#elif defined STM32F10X_MD
  #define FLASH_PAGE_SIZE    ((uint16_t)0x400)
#elif defined STM32F10X_HD
  #define FLASH_PAGE_SIZE    ((uint16_t)0x800)
#elif defined STM32F10X_CL
  #define FLASH_PAGE_SIZE    ((uint16_t)0x800)  
#endif /* STM32F10X_LD */

#define StartAddr  ((uint32_t)0x08006000)
#define EndAddr    ((uint32_t)0x08008000)

/* Uncomment this line to Enable Write Protection */
#define WriteProtection_Enable
/* Uncomment this line to Disable Write Protection */
//#define WriteProtection_Disable

uint32_t EraseCounter, Address;
uint16_t Data;
__IO uint32_t WRPR_Value = 0xFFFFFFFF, ProtectedPages = 0x0;
__IO uint8_t NbrOfPage = 0x00;
volatile FLASH_Status FLASHStatus;
volatile TestStatus MemoryProgramStatus;

void Flash_Test(void)
{
    printf("Flash_Test() Start\n");

    /* Unlock the Flash Program Erase controller */
    FLASH_Unlock();

    /* Define the number of page to be erased */
    NbrOfPage = (EndAddr - StartAddr) / FLASH_PAGE_SIZE;

    FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP|FLASH_FLAG_PGERR |FLASH_FLAG_WRPRTERR);

    /* Get pages write protection status */
    WRPR_Value = FLASH_GetWriteProtectionOptionByte();
    printf("WRPR_Value: 0x%0X\n", WRPR_Value);
    ProtectedPages = WRPR_Value & 0x000000C0;
    printf("ProtectedPages: 0x%0X\n", ProtectedPages);

#ifdef WriteProtection_Disable
    printf("WriteProtection_Disable\n");
    if (ProtectedPages == 0x00) /* Pages are write protected */
    {
        printf("ProtectedPages == 0x00\n");

        /* Disable the write protection */
        FLASHStatus = FLASH_EraseOptionBytes();
        printf("FLASHStatus: %d\n", FLASHStatus);

        /* Generate System Reset to load the new option byte values */
        Delay(500);
        NVIC_SystemReset();
    }
#elif defined WriteProtection_Enable
    printf("WriteProtection_Enable\n");
    if (ProtectedPages != 0x00)
    {
        printf("ProtectedPages != 0x00\n");

        /* Pages not write protected */
#if defined (STM32F10X_LD) || defined (STM32F10X_MD)
        /* Enable the pages write protection */
        FLASHStatus = FLASH_EnableWriteProtection(FLASH_WRProt_Pages24to27 |FLASH_WRProt_Pages28to31);    
#else /* (STM32F10X_HD) || defined (STM32F10X_CL) */  
        /* Enable the pages write protection */
        FLASHStatus = FLASH_EnableWriteProtection(FLASH_WRProt_Pages12to13 |FLASH_WRProt_Pages14to15);
#endif
        printf("FLASHStatus: %d\n", FLASHStatus);

        /* Generate System Reset to load the new option byte values */
        Delay(500);
        NVIC_SystemReset();
    }
#endif

    DEBUG_MSG_FUNC_NOTIFY;

    /* If Pages are not write protected, perform erase and program operations
    Else nothing */
    if (ProtectedPages != 0x00)
    {
        /* Clear All pending flags */
        FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP|FLASH_FLAG_PGERR |FLASH_FLAG_WRPRTERR);	

        /* erase the FLASH pages */
        for(EraseCounter = 0; (EraseCounter < NbrOfPage) && (FLASHStatus == FLASH_COMPLETE); EraseCounter++)
        {
            FLASHStatus = FLASH_ErasePage(StartAddr + (FLASH_PAGE_SIZE * EraseCounter));
            printf("EraseCounter: %d, FLASHStatus: %d\n", EraseCounter, FLASHStatus);
            printf("Erase Page Addr: 0x%0X\n", StartAddr + (FLASH_PAGE_SIZE * EraseCounter));
        }

        /* FLASH Half Word program of data 0x1753 at addresses defined by  StartAddr and EndAddr */
        Address = StartAddr;

        while((Address < EndAddr) && (FLASHStatus == FLASH_COMPLETE))
        {
            FLASHStatus = FLASH_ProgramHalfWord(Address, Data);
            printf("Address: 0x%0X, Data: 0x%0X, FLASHStatus: %d\n", Address, Data, FLASHStatus);
            Address = Address + 2;
        }

        Delay(500);

        /* Check the corectness of written data */
        Address = StartAddr;

        while((Address < EndAddr) && (MemoryProgramStatus != FAILED))
        {
            if((*(__IO uint16_t*) Address) != Data)
            {
                MemoryProgramStatus = FAILED;
                printf("[FAILED] Address: 0x%0X, Data: 0x%0X\n",
                       Address, (*(__IO uint16_t*) Address));
            }
            Address += 2;
        }
    }

    if(PASSED == MemoryProgramStatus)
    {
        printf("Memory check PASSED\n");
    }
    else
    {
        printf("Memory check FAILED\n");
    }

    while (1)
    {
    }
}

/*
 * Name   : main
 * Input  : None
 * Output : None
 * Return : None
 */
int main(void)
{
//    uint8_t ch;

    FLASHStatus = FLASH_COMPLETE;
    MemoryProgramStatus = PASSED;
    Data = 0x1753;
    EraseCounter = 0x0;

    /* System Clocks Configuration */
    RCC_Configuration();

    RCC_GetClocksFreq(&rcc_clocks);

    /* NVIC configuration */
    NVIC_Configuration();

    /* Configure the GPIO ports */
    GPIO_Configuration();

    /* EXTI configuration */
    EXTI_Configuration();

    /* UART initialization */
    USART1_Init();

    /* Setup SysTick Timer for 1 msec interrupts  */
    if (SysTick_Config(rcc_clocks.SYSCLK_Frequency / 1000))
    { 
        /* Capture error */ 
        while (1);
    }

    USB_Cable_Config(DISABLE);

    Delay(500);

    LED_Off_All();
    USART_GetCharacter(USART1);
    Flash_Test();

#if 0
    while(1)
    {
        printf("\n---------------------\n");
#ifdef BOARD_DEF_MANGO_M32
        printf("Mango M32 test start...\n");
#elif  BOARD_DEF_MANGO_Z1
        printf("Mango Z1 test start...\n");
#endif
        printf("Press menu key\n");
        printf("---------------------\n");
        printf("0> System Information\n");
        printf("---------------------\n");
        printf("1> LED Test\n");
        printf("2> KEY Test\n");
#ifdef BOARD_DEF_MANGO_M32
        printf("3> 7-Segment Test\n");
#elif  BOARD_DEF_MANGO_Z1
        printf("3> ZigBee Test\n");
#endif
        printf("4> USB HID Test\n");
        printf("5> \n");
        printf("---------------------\n");
        printf("x> quit\n\n");

        ch = USART_GetCharacter(USART1);
        printf(" is selected\n\n");

        switch((char)ch)
        {
        case '0':
            System_Information();
            break;

        case '1':
            LED_Test();
            break;

        case '2':
            KEY_Test();
            break;

        case '3':
#ifdef BOARD_DEF_MANGO_M32
            Seven_Segment_Test();
#elif  BOARD_DEF_MANGO_Z1
            ZigBee_Test();
#endif
            break;

        case '4':
            g_TestProcessState = TRUE;

            /* USB initialization */
            USB_Test_Start();
            Delay(500);
            USB_Cable_Config(ENABLE);
            break;

        case '5':
            break;
        }

        if('x' == (char)ch)
        {
            break;
        }
    }
#endif

    return 0;
}
